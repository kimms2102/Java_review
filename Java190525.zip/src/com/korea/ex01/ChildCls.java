package com.korea.ex01;

public class ChildCls extends AbstractCls{

	public void m2() {
		// TODO Auto-generated method stub
		
	}
	
}
