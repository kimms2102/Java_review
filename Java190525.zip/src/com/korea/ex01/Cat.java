package com.korea.ex01;

public class Cat extends Animal {

	public Cat() {
		this.kind = "������";
	}
	
	@Override
	public void sound() {
		System.out.println("�߿�");
		
	}
	

}
