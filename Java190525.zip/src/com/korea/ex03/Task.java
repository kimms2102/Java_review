package com.korea.ex03;

public interface Task {
	void todo();
	void goToWork();
	void leaveWork();
}
