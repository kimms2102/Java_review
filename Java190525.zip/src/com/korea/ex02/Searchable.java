package com.korea.ex02;

public interface Searchable {
	void search(String url);
}
