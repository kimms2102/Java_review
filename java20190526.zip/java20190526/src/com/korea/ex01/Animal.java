package com.korea.ex01;

public class Animal {

}
