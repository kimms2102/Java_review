package com.korea.ex01;

public class Dog extends Animal{

}
