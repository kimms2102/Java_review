package com.korea.ex01;

public class NumberFormatExceptionEx {

	public static void main(String[] args) {
		String data = "A101";
		int value = Integer.parseInt(data);
		System.out.println(value);

	}

}
