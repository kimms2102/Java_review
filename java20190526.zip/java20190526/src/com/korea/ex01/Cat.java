package com.korea.ex01;

public class Cat extends Animal {

}
