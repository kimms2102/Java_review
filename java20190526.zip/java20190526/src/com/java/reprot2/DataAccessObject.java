package com.java.reprot2;

public interface DataAccessObject {
	 void select();
	void insert();
	void update();
	void delete();
}
