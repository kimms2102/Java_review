package com.java.report;

public interface Soundable {
	String sound();
}
