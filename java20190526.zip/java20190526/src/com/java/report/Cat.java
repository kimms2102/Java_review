package com.java.report;

public class Cat implements Soundable {

	@Override
	public String sound() {
		
		return "�߿�";
	}

}
