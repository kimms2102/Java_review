package com.java.report;

public class Dog implements Soundable {

	@Override
	public String sound() {
		
		return "�۸�";
	}
	
}
